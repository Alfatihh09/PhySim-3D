// Netlify Function: proxies prompts to Gemini. The API key stays server-side.
const MODEL = "gemini-2.5-flash";
const json = (status, obj) => new Response(JSON.stringify(obj), { status, headers: { "Content-Type": "application/json" } });

export default async (req) => {
  if (req.method !== "POST") return json(405, { error: "Method not allowed" });
  const key = process.env.GEMINI_API_KEY;
  if (!key) return json(500, { error: "GEMINI_API_KEY is not set" });

  let body;
  try { body = await req.json(); } catch { return json(400, { error: "Invalid JSON" }); }
  const prompt = typeof body.prompt === "string" ? body.prompt.slice(0, 8000) : "";
  if (!prompt) return json(400, { error: "Missing prompt" });

  const parts = [{ text: prompt }];
  const img = body.image;
  if (img && typeof img.data === "string" && /^image\//.test(img.mime || "") && img.data.length < 5_000_000) {
    parts.push({ inline_data: { mime_type: img.mime, data: img.data } });
  }

  const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-goog-api-key": key },
    body: JSON.stringify({ contents: [{ parts }], ...(body.json ? { generationConfig: { responseMimeType: "application/json" } } : {}) }),
  });
  if (!r.ok) return json(r.status === 429 ? 429 : 502, { error: "Gemini error " + r.status + ": " + (await r.text()).slice(0, 200) });
  const d = await r.json();
  const text = (d.candidates?.[0]?.content?.parts ?? []).map((p) => p.text ?? "").join("");
  return json(200, { text });
};

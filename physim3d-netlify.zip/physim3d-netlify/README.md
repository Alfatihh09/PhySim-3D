# PhySim 3D

Simulasi fisika 3D (Kelas 10-11), derivasi rumus dua lapis, latihan soal, dan tutor AI.

## Struktur
- `index.html` : seluruh aplikasi (Three.js dan KaTeX dimuat dari CDN)
- `netlify/functions/ai.mjs` : proxy ke Gemini, API key tetap di server
- `netlify.toml` : konfigurasi publish dan redirect `/api/ai`

## Deploy
1. Buat repo GitHub, lalu `git init && git add . && git commit -m "PhySim 3D" && git push`
2. Netlify > Add new site > Import an existing project > pilih repo
   (build command kosong, publish directory `.`)
3. Site configuration > Environment variables > tambahkan `GEMINI_API_KEY`
   (buat di https://aistudio.google.com/apikey), lalu redeploy
4. Tanpa key, semua fitur tetap jalan kecuali tutor AI dan tombol "Selesaikan dengan AI"

## Uji lokal
`npm i -g netlify-cli`, buat `.env` berisi `GEMINI_API_KEY=...`, lalu `netlify dev`
